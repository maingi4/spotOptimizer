"use strict";
var Contracts;
(function (Contracts) {
    var OptimizeRq = (function () {
        function OptimizeRq() {
        }
        return OptimizeRq;
    }());
    Contracts.OptimizeRq = OptimizeRq;
    var ScalesOn = (function () {
        function ScalesOn() {
        }
        return ScalesOn;
    }());
    Contracts.ScalesOn = ScalesOn;
    var RequestCount = (function () {
        function RequestCount() {
        }
        return RequestCount;
    }());
    Contracts.RequestCount = RequestCount;
    var CPU = (function () {
        function CPU() {
        }
        return CPU;
    }());
    Contracts.CPU = CPU;
})(Contracts = exports.Contracts || (exports.Contracts = {}));
//# sourceMappingURL=optimizeRq.js.map